lvim.colorscheme = "rose-pine"

-- @usage 'base' | 'moon' | 'dawn' | 'rose-pine[-moon][-dawn]'
vim.g.tokyonight_style = "dawn"

-- Lualine
lvim.builtin.lualine.options.theme= "rose-pine"
