lvim.colorscheme = "nord"

-- Types of colors dark, storm, day is not a colorscheme
-- vim.g.tokyonight_style = "storm"
-- vim.g.nord_enable_sidebar_background = "true"
vim.g.nord_disable_background = false
vim.g.colors_name = "nord"


-- Lualine
lvim.builtin.lualine.options.theme= "nord"
