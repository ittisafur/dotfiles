
-- Types of colors dark, storm, day is not a colorscheme
vim.g.tokyonight_style = "dark"

lvim.colorscheme = "tokyonight"
-- Lualine
lvim.builtin.lualine.options.theme= "tokyonight"

