lvim.colorscheme = "poimandres"

vim.g.colors_name = "poimandres"


-- Lualine
lvim.builtin.lualine.options.theme= "poimandres"
