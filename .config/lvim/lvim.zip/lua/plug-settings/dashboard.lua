-- lvim.g.dashboard_custom_header = lvim.builtin.dashboard.custom_header
lvim.builtin.alpha.mode = "dashboard"
-- lvim.builtin.alpha.mode = "startify"

