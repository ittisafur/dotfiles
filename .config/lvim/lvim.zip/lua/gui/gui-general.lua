-- vim.o.guifont = "MonoLisa:h7:antialias=true:autocmd=false"

-- Add Firacode Nerd Font
-- vim.o.guifont = "Firacode:h6"
vim.g.colors_name = "nord"

-- vim.opt.guifont = "Roboto Mono Bold:h10"
-- vim.opt.guifont = "Pine:h10"

-- vim.cmd [[
--   set linespace=15
-- ]]


require('gui.neovide')
